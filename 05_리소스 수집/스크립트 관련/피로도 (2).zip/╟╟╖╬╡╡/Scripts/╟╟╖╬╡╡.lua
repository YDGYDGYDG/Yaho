fatigue1 = Image("Pictures/pelo1.png", Rect(Client.width / 9, Client.height / 14, 96, 10))--픽쳐에 있는 사진꼭꼭을 자신의 게임에 넣어주세요!
fatigue = Image("Pictures/pelo.png", Rect(Client.width / 9, Client.height / 14, 96, 10))
tex = Text('100%', Rect(Client.width / 4, Client.height / 14, 70, 10))
tex.textSize = 9

Client.GetTopic("피로도서버").Add(function(fatigued)
    fatigue.DOScale(Point(fatigued/100, 1), 0.5)--여기 숫자 100을 자신의 최대 피로도를 설정해주시길 바랍니다!
    tex.text = fatigued.."%"--만약 자신의게임의 피로도가 100이 아니라 다른거일경우 150% 500% 이렇게 될수 있어요! 
end)